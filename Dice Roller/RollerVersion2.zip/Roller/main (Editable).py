debugMode = False
windowTitle = "Dice"
glassMode = False
sides = 6


def forceSetSides():
    global sides
    def command():
        global sides
        try:
            if 1 <= int(input.get()) <= 12:
                print("Value force to sides var successful; Sides is now: {}".format(str(sides)))
                sides = int(input.get())
                input.pack_forget()
                submit.pack_forget()
            else:
                print("Must be between 1 and 12.")
        except ValueError:
            print("This variable must be an integer; sides variable will not change.")

    input = Entry(window)
    submit = Button(window, command= lambda: command(), text="Force Value")
    input.pack()
    submit.pack()

def changeTitle():
    print("Title changed to: {}".format(str(input.get())))
    def command():
        window.title(str(input.get()))
        input.pack_forget()
        submit.pack_forget()
    input = Entry(window)
    submit = Button(window, command= lambda: command(), text="Set Title")
    input.pack()
    submit.pack()

def ToggleGlassMode():
    global glassMode
    glassMode = not glassMode
    if glassMode is True:
        window.wm_attributes('-alpha', 0.5)
    if glassMode is False:
        window.wm_attributes('-alpha', 1)
    print("Glassmode: {}".format(str(glassMode)))

def UnlockResize():
    print("Feel free to resize as you wish!")
    window.resizable(-1,-1)

def ohno():
    print(":(")
    while True:
        window.resizable(-1,-1)
        Roll("oh no")

def EnableDebug():
    print("ENABLING DEBUG MODE")
    global debugmenu
    global debugMode
    debugMode = True

    if debugMode is True:
        debugmenu = Menu(window)
        debugmenu.add_command(label="I wonder what this does...", command = lambda: ohno())
        debugmenu.add_command(label="Force set sides variable",command = lambda: forceSetSides())
        debugmenu.add_command(label="Make another debug menu!",command = lambda: EnableDebug())
        debugmenu.add_command(label="Glass mode toggle",command = lambda: ToggleGlassMode())
        debugmenu.add_command(label="Throw away the menubar",command = lambda: menubar.destroy())
        debugmenu.add_command(label="Change title",command = lambda: changeTitle())
        debugmenu.add_command(label="Resize window",command = lambda: UnlockResize())
        menubar.add_cascade(label="Debug",menu=debugmenu)


def ChangeSides(numOfSides):
    global sides
    sides = numOfSides
    display.config(image=blank)
    print("Changing number of sides to: {}".format(str(sides)))

def Contact():
    messagebox.showinfo("Contact", "You can contact me at: 'admin@bohdan.co'")

def About():
    messagebox.showinfo("About", "This dice game is made and coded by Bohdan Pike.\nVersion 1.\nThanks for Playing!")
    

def InterruptLoop():
    exit()


defaultSides = ["One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Zero", "Ten", "Eleven", "Twelve"]

def Roll(e):
    currentNumber = randint(1, sides)
    if debugMode is True:
        print(str(e) + ";{}".format(currentNumber))
    else:
        print("You rolled a {}! :D".format(currentNumber))
    i = 1
    for number in defaultSides:
        exec('if currentNumber == {}:display.config(image = {})'.format(i,number))
        if i <= 12:
            i = i + 1
    display.update()

from tkinter import ttk
from tkinter import *
from tkinter import messagebox
from random import randint

window = Tk()
window.title(windowTitle)
try:
    window.iconbitmap(".\Resources\icon.ico")
except TclError:
    if debugMode is True:
        print("Can't find icon file at: \"" + iconDirectory + "\"; Catching exception.")


blank = PhotoImage(file=".\\Resources\\Blank.gif")

for number in defaultSides:
    source = "\".\Resources\\" + number + ".gif\""
    exec('{} = PhotoImage(file={})'.format(number, source))


display = Label(window, image=blank)
display.pack()
window.bind("<Return>", Roll)
window.resizable(0,0)
if glassMode is True:
    window.wm_attributes('-alpha', 0.5)



menubar=Menu(window)
filemenu = Menu(menubar)
filemenu.add_command(label="Exit", command = InterruptLoop)
filemenu.add_command(label="Enable Debug Mode", command = lambda: EnableDebug())
menubar.add_cascade(label="File",menu=filemenu)

sidemenu = Menu(window)
sidemenu.add_command(label="Four Sides",command = lambda: ChangeSides(4))
sidemenu.add_command(label="Six Sides",command = lambda: ChangeSides(6))
sidemenu.add_command(label="Twelve Sides",command = lambda: ChangeSides(12))
menubar.add_cascade(label="Sides",menu=sidemenu)

helpmenu = Menu(window)
helpmenu.add_command(label="About",command = About)
helpmenu.add_command(label="Contact",command = Contact)
menubar.add_cascade(label="Help",menu=helpmenu)

window.config(menu=menubar)

messagebox.showinfo("How to use", "Press ENTER to roll the dice.")


window.mainloop()
